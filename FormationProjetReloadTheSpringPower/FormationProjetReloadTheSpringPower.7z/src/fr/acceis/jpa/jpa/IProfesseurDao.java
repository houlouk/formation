package fr.acceis.jpa.jpa;

import model.Professeur;

public interface IProfesseurDao extends Dao<Professeur, Long> {

}
