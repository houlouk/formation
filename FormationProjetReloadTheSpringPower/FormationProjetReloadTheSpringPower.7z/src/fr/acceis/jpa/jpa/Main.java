package fr.acceis.jpa.jpa;

public class Main {

	public static void main(String[] args) {
		
	/*	Session session = HibernateUtil.getSessionFactory().openSession();
		
		Matiere matiere = session.load(Matiere.class, new Long(4));
		System.out.println(matiere.getNom());
		
		session.close();
		
		// TODO Auto-generated method stub*/

	}

}
