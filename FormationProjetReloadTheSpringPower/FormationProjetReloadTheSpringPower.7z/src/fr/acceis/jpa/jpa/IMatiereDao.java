package fr.acceis.jpa.jpa;

import model.Matiere;

public interface IMatiereDao extends Dao<Matiere, Long> {

}
