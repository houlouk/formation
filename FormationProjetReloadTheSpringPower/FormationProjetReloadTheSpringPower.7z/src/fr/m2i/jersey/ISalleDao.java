package fr.m2i.jersey;

import fr.acceis.jpa.jpa.Dao;
import model.Salle;

public interface ISalleDao extends Dao<Salle, Long> {

}
