package generator;

public interface ParcourableString {

	String parcourir(Class<?> clazz, String packageName);

}
