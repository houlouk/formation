package generator;

public class ModelForShowConstants {

	static final String MODEL_ID_NAME_FIRST_CAP = "#modelIdNamFirstCap";
	static final String MODEL_NAME = "#modelName";
	static final String MODEL_CLASS = "#modelClass";
	static final String MODEL_ID_TYPE = "#modelIdType";
	static final String ATT_NAME_FIRST = "#attNamBeFirst";
	static final String ATT_NAME = "#attName";
	static final String ATT_TYPE = "#attType";
	static final String MODEL_ID_NAME = "#modelIdName";

}
