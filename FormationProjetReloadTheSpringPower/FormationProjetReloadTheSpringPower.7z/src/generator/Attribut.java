package generator;

public class Attribut {

	private String name;
	private String type;

	public Attribut(String name, String type) {
		this.name=name;
		this.type=type;
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public String getType() {
		return type;
	}

}
